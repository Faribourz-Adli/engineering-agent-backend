# Engineering Agent Backend (MVP)

This is a minimal FastAPI service used for the MVP:
- Creates upload sessions
- Processes files stored in Supabase (OCR + simple parsing)
- Stores standards/sections/terms in Postgres (Supabase)
- Lists standards and returns detail with sections and extracted terms

## Endpoints
- `GET /api/health`
- `POST /api/upload/start`  (body: `{ "user_email": "you@example.com", "org_name": "Demo Co", "note": "demo" }`)
- `POST /api/process/enqueue` (body: `{ "upload_session_id": "uuid", "file_path": "folder/file.pdf" }`)
- `GET /api/standards`
- `GET /api/standards/{standard_id}`

## Deploy (Render.com, Docker)
1. Create a new GitHub repo and upload these files (`app.py`, `requirements.txt`, `Dockerfile`).
2. On Render: New → Web Service → Connect GitHub → pick this repo → Environment = Docker.
3. Add environment variables from `.env.example` (use your Supabase values).
4. Deploy, then open `/api/health` to test.
